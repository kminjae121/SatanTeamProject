using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiceItem : MonoBehaviour, IUseItem
{
    public void Use()
    {
        print("�ֻ���");
    }
}
