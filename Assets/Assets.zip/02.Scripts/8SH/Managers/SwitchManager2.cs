using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class SwitchManager2 : MonoBehaviour
{
    [SerializeField] private bool isOn = false;
    public UnityEvent onEvent;
    public UnityEvent offEvent;

    [Header("Audio")]
    [SerializeField] private AudioSource clickAudio;
    private TextMeshProUGUI text;

    [Header("Settings")]
    [SerializeField] private string switchName = "����";
    private string filePath;

    private void Start()
    {
        // �ؽ�Ʈ ���� ��� ����
        filePath = Application.persistentDataPath + "/SwitchSettings.txt";

        // �ʱ�ȭ
        text = GetComponent<TextMeshProUGUI>();
        LoadState(); // ���Ͽ��� ���� �ҷ�����

        UpdateText();
    }

    private void Toggle()
    {
        isOn = !isOn; // ���� ��ȯ
        if (isOn)
        {
            onEvent?.Invoke();
        }
        else
        {
            offEvent?.Invoke();
        }

        UpdateText();
        SaveState(); // ���¸� ���Ͽ� ����
    }

    public void Click()
    {
        Toggle();
        clickAudio.Play();
    }

    private void UpdateText()
    {
        text.text = isOn ? "����" : "����";
    }

    private void SaveState()
    {
        // ���� ���� �б�
        Dictionary<string, string> settings = new Dictionary<string, string>();
        if (File.Exists(filePath))
        {
            foreach (var line in File.ReadAllLines(filePath))
            {
                if (line.Contains(":"))
                {
                    var split = line.Split(':');
                    settings[split[0].Trim()] = split[1].Trim();
                }
            }
        }

        // ���� ����ġ ���� ������Ʈ
        settings[switchName] = isOn ? "True" : "False";

        // �� ���� ����
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            foreach (var kvp in settings)
            {
                writer.WriteLine($"{kvp.Key} : {kvp.Value}");
            }
        }
    }

    private void LoadState()
    {
        if (File.Exists(filePath))
        {
            foreach (var line in File.ReadAllLines(filePath))
            {
                if (line.StartsWith(switchName))
                {
                    var split = line.Split(':');
                    if (split.Length > 1)
                    {
                        isOn = split[1].Trim().ToLower() == "true";
                    }
                }
            }
        }
    }
}