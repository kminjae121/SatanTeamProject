using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public enum SprintType
{
    Hold,
    Toggle
}

public class SettingManager : MonoBehaviour
{
    private static SettingManager instance;
    public static SettingManager Instance
    {
        get
        {
            if (instance == null)
            {
                GameObject settingsManagerObj = new GameObject("SettingsManager");
                instance = settingsManagerObj.AddComponent<SettingManager>();
                DontDestroyOnLoad(settingsManagerObj);
            }
            return instance;
        }
    }

    [Header("Settings")]
    public Dictionary<string, bool> boolSettings = new Dictionary<string, bool>
    {
        { "CameraShake", true },
        { "UiVisible", true },
        { "MotionBlur", true },
    };

    [Header("Objects")]
    [SerializeField] private Slider sensitivitySlider;
    [SerializeField] private Slider brightnessSlider;
    [SerializeField] private Slider gammaSlider;

    public int mouseLRInversion = 1;
    public int mouseUDInversion = 1;
    public float _sensitivity = 1.5f;

    public SprintType SprintMode { get; set; } = SprintType.Hold;

    private string filePath;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else if (instance != this)
        {
            Destroy(this.gameObject);
        }

        // ���� ���� ��� ����
        filePath = Path.Combine(Application.persistentDataPath, "Settings.txt");
        LoadSettingsFromFile(); // ���Ͽ��� ���� �ҷ�����
    }

    private void OnApplicationQuit()
    {
        SaveSettingsToFile(); // �� ���� �� ���� ����
    }

    public GameObject FindGameObjectByName(string name)
    {
        GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();

        foreach (GameObject obj in allObjects)
        {
            if (obj.name == name)
            {
                return obj;
            }
        }

        Debug.LogWarning($"GameObject with name '{name}' not found.");
        return null;
    }

    #region ���� ���� �� �ҷ�����

    private void SaveSettingsToFile()
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            // boolSettings ����
            foreach (var setting in boolSettings)
            {
                writer.WriteLine($"{setting.Key} : {setting.Value}");
            }

            // ��Ÿ ���� ���� (��: SprintMode, ���콺 ���� ��)
            writer.WriteLine($"SprintMode : {SprintMode}");
            writer.WriteLine($"MouseLRInversion : {mouseLRInversion}");
            writer.WriteLine($"MouseUDInversion : {mouseUDInversion}");
            writer.WriteLine($"Sensitivity : {_sensitivity}");
        }
    }

    private void LoadSettingsFromFile()
    {
        if (!File.Exists(filePath))
            return; // ������ ������ �⺻�� ���

        foreach (var line in File.ReadAllLines(filePath))
        {
            var split = line.Split(':');
            if (split.Length < 2) continue;

            var key = split[0].Trim();
            var value = split[1].Trim();

            // boolSettings �ҷ�����
            if (boolSettings.ContainsKey(key))
            {
                boolSettings[key] = value.ToLower() == "true";
            }
            // ��Ÿ ���� �ҷ�����
            else if (key == "SprintMode")
            {
                SprintMode = value == "Hold" ? SprintType.Hold : SprintType.Toggle;
            }
            else if (key == "MouseLRInversion")
            {
                mouseLRInversion = int.Parse(value);
            }
            else if (key == "MouseUDInversion")
            {
                mouseUDInversion = int.Parse(value);
            }
            else if (key == "Sensitivity")
            {
                _sensitivity = float.Parse(value);
            }
        }
    }

    #endregion

    #region �����Լ���
    public bool GetSetting(string settingName)
    {
        return boolSettings.ContainsKey(settingName) && boolSettings[settingName];
    }

    public void ToggleSettingToOn(string settingName)
    {
        if (boolSettings.ContainsKey(settingName))
        {
            boolSettings[settingName] = true;
        }
    }

    public void ToggleSettingToOff(string settingName)
    {
        if (boolSettings.ContainsKey(settingName))
        {
            boolSettings[settingName] = false;
        }
    }

    public void ToggleSprintMode(bool isHold)
    {
        SprintMode = isHold ? SprintType.Hold : SprintType.Toggle;
    }

    public void SettingFloatValue(int type)
    {
        if (type == 1)
        {
            Sensitivity = sensitivitySlider.value;
        }
    }

    public float Sensitivity
    {
        get => _sensitivity;
        set => _sensitivity = Mathf.Clamp(value, 0.1f, 10f);
    }
    #endregion
}