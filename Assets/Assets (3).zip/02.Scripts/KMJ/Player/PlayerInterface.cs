using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInterface : MonoBehaviour
{
}

interface IMove
{
    public void Move();
}

interface IInteraction
{
    public void Interaction();   
}
