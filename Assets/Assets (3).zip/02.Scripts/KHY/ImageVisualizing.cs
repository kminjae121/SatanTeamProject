using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ImageVisualizing : MonoBehaviour
{
    public static float[] _bandBuffer = new float[8];
}
